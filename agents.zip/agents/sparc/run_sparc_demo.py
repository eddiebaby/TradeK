#!/usr/bin/env python3
"""
SPARC Integration Demo Runner

Run this script to see the complete SPARC methodology integration with your
TradeKnowledge project and existing MASTERMIND-EXECUTOR-RESEARCHER agents.
"""

import asyncio
import sys
from pathlib import Path

# Add current directory to path
sys.path.append(str(Path(__file__).parent))

from sparc_demo import demo_sparc_integration, demo_quality_gates, demo_boomerang_tasks
from sparc_integration import example_feature_development, tradeknowledge_sparc


async def main():
    """Run complete SPARC integration demonstration."""
    
    print("🚀 SPARC Methodology Integration - Complete Demo")
    print("=" * 55)
    print()
    print("This demonstration shows how the SPARC framework has been")
    print("integrated with your TradeKnowledge project and existing")
    print("MASTERMIND-EXECUTOR-RESEARCHER agent system.")
    print()
    
    try:
        # Run core SPARC demo
        print("📋 Running Core SPARC Methodology Demo...")
        await demo_sparc_integration()
        
        # Run quality gates demo
        print("\n" + "=" * 55)
        print("🛡️  Running Quality Gates Demo...")
        await demo_quality_gates()
        
        # Run boomerang tasks demo
        print("\n" + "=" * 55)
        print("🪃 Running Boomerang Task System Demo...")
        await demo_boomerang_tasks()
        
        # Run TradeKnowledge integration example
        print("\n" + "=" * 55)
        print("🏢 Running TradeKnowledge Integration Example...")
        integration_example = await example_feature_development()
        
        print("\n📊 TradeKnowledge Integration Results:")
        print("-" * 40)
        
        project = integration_example["project"]
        print(f"✅ Project: {project.title}")
        print(f"   Project ID: {project.project_id}")
        print(f"   Phases: {len(project.deliverables)} configured")
        
        results = integration_example["results"]
        if "execution_summary" in results:
            summary = results["execution_summary"]
            print(f"   Duration: {summary.get('total_duration', 0):.2f}s")
            print(f"   Quality Score: {summary.get('overall_quality_score', 0):.1f}/10")
        
        if "tradeknowledge_integration" in results:
            integration = results["tradeknowledge_integration"]
            print(f"   Integration Score: {integration.get('integration_quality_score', 0):.1f}%")
        
        # Show final integration report
        print("\n" + "=" * 55)
        print("📈 Final Integration Report")
        print("=" * 55)
        
        final_report = await tradeknowledge_sparc.generate_integration_report()
        print(final_report)
        
        # Show next steps
        print("\n" + "=" * 55)
        print("🚀 Next Steps for Production Use")
        print("=" * 55)
        
        next_steps = [
            "1. Review the generated SPARC files in agents/sparc/",
            "2. Integrate sparc_orchestrator.py with your existing agents",
            "3. Customize quality gates for your specific requirements",
            "4. Set up persistent storage for project tracking",
            "5. Add monitoring dashboards for SPARC workflow progress",
            "6. Train team members on SPARC methodology principles",
            "7. Start with a pilot project using the SPARC workflow"
        ]
        
        for step in next_steps:
            print(f"   {step}")
        
        print()
        print("🎉 SPARC Integration Complete!")
        print()
        print("The SPARC methodology is now fully integrated with your")
        print("TradeKnowledge project. You can begin using structured")
        print("development workflows immediately.")
        
        return True
        
    except Exception as e:
        print(f"❌ Demo failed with error: {e}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    success = asyncio.run(main())
    exit_code = 0 if success else 1
    sys.exit(exit_code)