"""
SPARC Communication Protocols - Structured Agent Handoffs

This module implements the structured communication protocols and handoff standards
for SPARC methodology with MASTERMIND, EXECUTOR, and RESEARCHER agents.
"""

import asyncio
import time
import json
from typing import Dict, List, Any, Optional, Union
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path

import sys
sys.path.append(str(Path(__file__).parent.parent))

from core.agent_base import AgentRole


class MessageType(Enum):
    """SPARC message types for structured communication."""
    REQUEST = "request"
    INFORM = "inform"
    CONFIRM = "confirm"
    REFUSE = "refuse"
    HANDOFF = "handoff"
    QUALITY_REVIEW = "quality_review"
    REFINEMENT_REQUEST = "refinement_request"
    STATUS_UPDATE = "status_update"


class Priority(Enum):
    """Message priority levels."""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


@dataclass
class SPARCMessage:
    """Structured message for SPARC agent communication."""
    message_id: str
    from_agent: AgentRole
    to_agent: Union[AgentRole, str]  # Can be "ALL" for broadcast
    phase: str
    message_type: MessageType
    content: Dict[str, Any]
    priority: Priority = Priority.MEDIUM
    deadline: Optional[float] = None
    context: Dict[str, Any] = field(default_factory=dict)
    timestamp: float = field(default_factory=time.time)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert message to dictionary format."""
        return {
            "message_id": self.message_id,
            "from_agent": self.from_agent.value if isinstance(self.from_agent, AgentRole) else self.from_agent,
            "to_agent": self.to_agent.value if isinstance(self.to_agent, AgentRole) else self.to_agent,
            "phase": self.phase,
            "message_type": self.message_type.value,
            "content": self.content,
            "priority": self.priority.value,
            "deadline": self.deadline,
            "context": self.context,
            "timestamp": self.timestamp
        }


@dataclass
class HandoffValidation:
    """Validation checklist for SPARC handoffs."""
    task_scope_defined: bool = False
    success_criteria_clear: bool = False
    context_provided: bool = False
    constraints_documented: bool = False
    deliverables_specified: bool = False
    timeline_established: bool = False
    quality_standards_defined: bool = False
    escalation_procedures_clear: bool = False
    
    @property
    def is_valid(self) -> bool:
        """Check if handoff meets all validation requirements."""
        return all([
            self.task_scope_defined,
            self.success_criteria_clear,
            self.context_provided,
            self.constraints_documented,
            self.deliverables_specified,
            self.timeline_established,
            self.quality_standards_defined,
            self.escalation_procedures_clear
        ])
    
    @property
    def completion_percentage(self) -> float:
        """Get handoff validation completion percentage."""
        completed = sum([
            self.task_scope_defined,
            self.success_criteria_clear,
            self.context_provided,
            self.constraints_documented,
            self.deliverables_specified,
            self.timeline_established,
            self.quality_standards_defined,
            self.escalation_procedures_clear
        ])
        return (completed / 8) * 100


class SPARCCommunicationProtocol:
    """
    SPARC Communication Protocol Manager
    
    Manages structured communication between agents following SPARC methodology.
    Implements handoff validation, message routing, and communication standards.
    """
    
    def __init__(self):
        self.message_queue: Dict[AgentRole, List[SPARCMessage]] = {
            AgentRole.MASTERMIND: [],
            AgentRole.EXECUTOR: [],
            AgentRole.RESEARCHER: []
        }
        
        self.communication_history: List[SPARCMessage] = []
        self.active_handoffs: Dict[str, Dict[str, Any]] = {}
        
        # Communication templates for each phase
        self.phase_templates = self._initialize_phase_templates()
        
        # Message validation rules
        self.validation_rules = self._initialize_validation_rules()
        
    def _initialize_phase_templates(self) -> Dict[str, Dict[str, Any]]:
        """Initialize communication templates for each SPARC phase."""
        return {
            "specification": {
                "mastermind_to_researcher": {
                    "template": "Research requirements for {domain}, focus on {specific_areas}",
                    "required_fields": ["domain", "specific_areas", "depth", "timeline"],
                    "expected_deliverables": ["market_analysis", "best_practices", "regulatory_requirements"]
                },
                "mastermind_to_executor": {
                    "template": "Validate technical feasibility of requirements: {requirements}",
                    "required_fields": ["requirements", "constraints", "timeline"],
                    "expected_deliverables": ["feasibility_assessment", "resource_estimation", "risk_analysis"]
                },
                "researcher_to_mastermind": {
                    "template": "Requirements research complete: {findings}",
                    "required_fields": ["findings", "recommendations", "confidence_level"],
                    "expected_response": "requirements_integration"
                },
                "executor_to_mastermind": {
                    "template": "Technical feasibility assessment: {assessment}",
                    "required_fields": ["assessment", "implementation_approach", "constraints"],
                    "expected_response": "specification_finalization"
                }
            },
            "pseudocode": {
                "mastermind_to_researcher": {
                    "template": "Research optimal algorithms and patterns for {functionality}",
                    "required_fields": ["functionality", "performance_requirements", "constraints"],
                    "expected_deliverables": ["algorithm_analysis", "pattern_recommendations", "performance_implications"]
                },
                "mastermind_to_executor": {
                    "template": "Validate pseudocode implementation feasibility: {pseudocode}",
                    "required_fields": ["pseudocode", "technical_constraints", "performance_targets"],
                    "expected_deliverables": ["implementation_assessment", "complexity_analysis", "optimization_suggestions"]
                },
                "researcher_to_executor": {
                    "template": "Algorithm research findings: {algorithms}",
                    "required_fields": ["algorithms", "performance_analysis", "implementation_considerations"],
                    "expected_response": "implementation_validation"
                }
            },
            "architecture": {
                "mastermind_to_researcher": {
                    "template": "Research architecture patterns for {system_type} with {requirements}",
                    "required_fields": ["system_type", "requirements", "scalability_needs"],
                    "expected_deliverables": ["pattern_analysis", "technology_recommendations", "best_practices"]
                },
                "mastermind_to_executor": {
                    "template": "Validate proposed architecture for implementation feasibility",
                    "required_fields": ["architecture_design", "technology_stack", "deployment_strategy"],
                    "expected_deliverables": ["implementation_plan", "infrastructure_requirements", "deployment_validation"]
                },
                "researcher_to_mastermind": {
                    "template": "Architecture research complete: {patterns}",
                    "required_fields": ["patterns", "technology_evaluation", "recommendations"],
                    "expected_response": "architecture_refinement"
                }
            },
            "refinement": {
                "mastermind_to_all": {
                    "template": "Begin refinement cycle focusing on {focus_areas}",
                    "required_fields": ["focus_areas", "success_criteria", "timeline"],
                    "expected_deliverables": ["optimization_plan", "implementation_improvements", "quality_enhancements"]
                },
                "researcher_to_mastermind": {
                    "template": "Optimization research complete: {optimizations}",
                    "required_fields": ["optimizations", "performance_impact", "implementation_guidance"],
                    "expected_response": "refinement_approval"
                },
                "executor_to_mastermind": {
                    "template": "Refinement implementation complete: {improvements}",
                    "required_fields": ["improvements", "performance_results", "quality_metrics"],
                    "expected_response": "refinement_validation"
                }
            },
            "completion": {
                "executor_to_mastermind": {
                    "template": "Deployment preparation complete: {deployment_status}",
                    "required_fields": ["deployment_status", "quality_validation", "monitoring_setup"],
                    "expected_response": "completion_approval"
                },
                "mastermind_to_researcher": {
                    "template": "Research deployment best practices and operational requirements",
                    "required_fields": ["deployment_environment", "operational_needs", "maintenance_requirements"],
                    "expected_deliverables": ["deployment_guidelines", "operational_procedures", "maintenance_strategy"]
                },
                "researcher_to_executor": {
                    "template": "Deployment best practices: {practices}",
                    "required_fields": ["practices", "monitoring_strategies", "operational_guidelines"],
                    "expected_response": "deployment_implementation"
                }
            }
        }
    
    def _initialize_validation_rules(self) -> Dict[str, Any]:
        """Initialize message validation rules."""
        return {
            "required_fields": {
                MessageType.REQUEST: ["task_description", "deliverables", "timeline"],
                MessageType.HANDOFF: ["deliverables", "success_criteria", "constraints"],
                MessageType.QUALITY_REVIEW: ["review_criteria", "assessment_results"],
                MessageType.REFINEMENT_REQUEST: ["refinement_areas", "success_criteria"]
            },
            "field_validation": {
                "timeline": lambda x: isinstance(x, (int, float)) and x > 0,
                "priority": lambda x: x in [p.value for p in Priority],
                "deliverables": lambda x: isinstance(x, list) and len(x) > 0
            }
        }
    
    async def create_structured_handoff(self, 
                                       from_agent: AgentRole,
                                       to_agent: AgentRole,
                                       phase: str,
                                       task_description: str,
                                       context: Dict[str, Any]) -> SPARCMessage:
        """
        Create a structured handoff message between agents.
        
        Args:
            from_agent: Source agent
            to_agent: Target agent
            phase: SPARC phase
            task_description: Detailed task description
            context: Task context and requirements
            
        Returns:
            SPARCMessage: Structured handoff message
        """
        message_id = f"handoff_{int(time.time() * 1000)}"
        
        # Validate handoff requirements
        validation = self._validate_handoff_context(context)
        
        if not validation.is_valid:
            raise ValueError(f"Handoff validation failed. Completion: {validation.completion_percentage:.1f}%")
        
        # Create handoff message
        handoff_content = {
            "task_description": task_description,
            "deliverables": context.get("deliverables", []),
            "success_criteria": context.get("success_criteria", []),
            "constraints": context.get("constraints", []),
            "timeline": context.get("timeline", 24.0),  # hours
            "quality_standards": context.get("quality_standards", {}),
            "escalation_procedures": context.get("escalation_procedures", []),
            "context_data": context.get("context_data", {}),
            "performance_targets": context.get("performance_targets", {}),
            "validation_checklist": validation.__dict__
        }
        
        message = SPARCMessage(
            message_id=message_id,
            from_agent=from_agent,
            to_agent=to_agent,
            phase=phase,
            message_type=MessageType.HANDOFF,
            content=handoff_content,
            priority=Priority.HIGH,
            context=context
        )
        
        # Store active handoff
        self.active_handoffs[message_id] = {
            "message": message,
            "status": "active",
            "created_at": time.time(),
            "validation": validation
        }
        
        print(f"  🤝 Structured Handoff Created: {from_agent.value} → {to_agent.value}")
        print(f"     Phase: {phase}")
        print(f"     Task: {task_description}")
        print(f"     Validation: {validation.completion_percentage:.1f}% complete")
        
        return message
    
    def _validate_handoff_context(self, context: Dict[str, Any]) -> HandoffValidation:
        """Validate handoff context against requirements."""
        validation = HandoffValidation()
        
        # Check task scope definition
        validation.task_scope_defined = bool(
            context.get("task_description") and 
            len(context.get("task_description", "")) > 10
        )
        
        # Check success criteria
        validation.success_criteria_clear = bool(
            context.get("success_criteria") and 
            len(context.get("success_criteria", [])) > 0
        )
        
        # Check context provision
        validation.context_provided = bool(
            context.get("context_data") or 
            context.get("background_information")
        )
        
        # Check constraints documentation
        validation.constraints_documented = bool(
            context.get("constraints") and 
            len(context.get("constraints", [])) > 0
        )
        
        # Check deliverables specification
        validation.deliverables_specified = bool(
            context.get("deliverables") and 
            len(context.get("deliverables", [])) > 0
        )
        
        # Check timeline establishment
        validation.timeline_established = bool(
            context.get("timeline") and 
            isinstance(context.get("timeline"), (int, float))
        )
        
        # Check quality standards
        validation.quality_standards_defined = bool(
            context.get("quality_standards") or 
            context.get("acceptance_criteria")
        )
        
        # Check escalation procedures
        validation.escalation_procedures_clear = bool(
            context.get("escalation_procedures") or 
            context.get("issue_resolution")
        )
        
        return validation
    
    async def send_message(self, message: SPARCMessage) -> bool:
        """
        Send a message through the SPARC communication protocol.
        
        Args:
            message: Message to send
            
        Returns:
            bool: Success status
        """
        try:
            # Validate message
            if not self._validate_message(message):
                raise ValueError("Message validation failed")
            
            # Route message
            if message.to_agent == "ALL":
                # Broadcast message
                for agent in AgentRole:
                    if agent != message.from_agent:
                        self.message_queue[agent].append(message)
            else:
                # Direct message
                if isinstance(message.to_agent, str):
                    target_agent = AgentRole(message.to_agent)
                else:
                    target_agent = message.to_agent
                
                self.message_queue[target_agent].append(message)
            
            # Store in communication history
            self.communication_history.append(message)
            
            print(f"  📨 Message Sent: {message.from_agent.value} → {message.to_agent}")
            print(f"     Type: {message.message_type.value}")
            print(f"     Priority: {message.priority.value}")
            
            return True
            
        except Exception as e:
            print(f"  ❌ Message sending failed: {e}")
            return False
    
    def _validate_message(self, message: SPARCMessage) -> bool:
        """Validate message against protocol requirements."""
        # Check required fields for message type
        required_fields = self.validation_rules["required_fields"].get(message.message_type, [])
        
        for field in required_fields:
            if field not in message.content:
                print(f"Missing required field: {field}")
                return False
        
        # Validate specific field types
        for field, validator in self.validation_rules["field_validation"].items():
            if field in message.content:
                if not validator(message.content[field]):
                    print(f"Invalid field value: {field}")
                    return False
        
        return True
    
    async def receive_messages(self, agent: AgentRole) -> List[SPARCMessage]:
        """
        Receive messages for a specific agent.
        
        Args:
            agent: Agent to receive messages for
            
        Returns:
            List[SPARCMessage]: Messages for the agent
        """
        messages = self.message_queue.get(agent, [])
        self.message_queue[agent] = []  # Clear queue after reading
        
        if messages:
            print(f"  📬 {agent.value} received {len(messages)} messages")
        
        return messages
    
    async def create_phase_communication_plan(self, phase: str, agents: List[AgentRole]) -> Dict[str, Any]:
        """
        Create a communication plan for a specific SPARC phase.
        
        Args:
            phase: SPARC phase name
            agents: Agents involved in the phase
            
        Returns:
            Dict: Communication plan with message flows
        """
        templates = self.phase_templates.get(phase, {})
        
        communication_plan = {
            "phase": phase,
            "agents": [agent.value for agent in agents],
            "message_flows": [],
            "coordination_sequence": [],
            "handoff_protocols": []
        }
        
        # Define message flows based on phase
        if phase == "specification":
            communication_plan["message_flows"] = [
                {
                    "sequence": 1,
                    "from": "mastermind",
                    "to": "researcher", 
                    "purpose": "Requirements research request",
                    "template": templates.get("mastermind_to_researcher", {})
                },
                {
                    "sequence": 2,
                    "from": "mastermind",
                    "to": "executor",
                    "purpose": "Technical feasibility validation",
                    "template": templates.get("mastermind_to_executor", {})
                },
                {
                    "sequence": 3,
                    "from": "researcher",
                    "to": "mastermind",
                    "purpose": "Research findings delivery",
                    "template": templates.get("researcher_to_mastermind", {})
                },
                {
                    "sequence": 4,
                    "from": "executor",
                    "to": "mastermind",
                    "purpose": "Feasibility assessment delivery",
                    "template": templates.get("executor_to_mastermind", {})
                }
            ]
            
            communication_plan["coordination_sequence"] = [
                "MASTERMIND initiates specification phase",
                "RESEARCHER conducts requirements research",
                "EXECUTOR validates technical feasibility",
                "MASTERMIND integrates findings into specification",
                "All agents validate final specification"
            ]
            
        elif phase == "pseudocode":
            communication_plan["message_flows"] = [
                {
                    "sequence": 1,
                    "from": "mastermind",
                    "to": "researcher",
                    "purpose": "Algorithm research request",
                    "template": templates.get("mastermind_to_researcher", {})
                },
                {
                    "sequence": 2,
                    "from": "researcher",
                    "to": "executor",
                    "purpose": "Algorithm findings sharing",
                    "template": templates.get("researcher_to_executor", {})
                },
                {
                    "sequence": 3,
                    "from": "mastermind",
                    "to": "executor",
                    "purpose": "Pseudocode validation request",
                    "template": templates.get("mastermind_to_executor", {})
                }
            ]
            
        elif phase == "architecture":
            communication_plan["message_flows"] = [
                {
                    "sequence": 1,
                    "from": "mastermind",
                    "to": "researcher",
                    "purpose": "Architecture pattern research",
                    "template": templates.get("mastermind_to_researcher", {})
                },
                {
                    "sequence": 2,
                    "from": "researcher",
                    "to": "mastermind",
                    "purpose": "Architecture research delivery",
                    "template": templates.get("researcher_to_mastermind", {})
                },
                {
                    "sequence": 3,
                    "from": "mastermind",
                    "to": "executor",
                    "purpose": "Architecture validation request",
                    "template": templates.get("mastermind_to_executor", {})
                }
            ]
            
        elif phase == "refinement":
            communication_plan["message_flows"] = [
                {
                    "sequence": 1,
                    "from": "mastermind",
                    "to": "all",
                    "purpose": "Refinement cycle initiation",
                    "template": templates.get("mastermind_to_all", {})
                },
                {
                    "sequence": 2,
                    "from": "researcher",
                    "to": "mastermind",
                    "purpose": "Optimization research delivery",
                    "template": templates.get("researcher_to_mastermind", {})
                },
                {
                    "sequence": 3,
                    "from": "executor",
                    "to": "mastermind",
                    "purpose": "Implementation improvements delivery",
                    "template": templates.get("executor_to_mastermind", {})
                }
            ]
            
        elif phase == "completion":
            communication_plan["message_flows"] = [
                {
                    "sequence": 1,
                    "from": "mastermind",
                    "to": "researcher",
                    "purpose": "Deployment best practices research",
                    "template": templates.get("mastermind_to_researcher", {})
                },
                {
                    "sequence": 2,
                    "from": "researcher",
                    "to": "executor",
                    "purpose": "Deployment guidelines delivery",
                    "template": templates.get("researcher_to_executor", {})
                },
                {
                    "sequence": 3,
                    "from": "executor",
                    "to": "mastermind",
                    "purpose": "Deployment completion notification",
                    "template": templates.get("executor_to_mastermind", {})
                }
            ]
        
        return communication_plan
    
    def get_communication_metrics(self) -> Dict[str, Any]:
        """Get communication protocol metrics."""
        total_messages = len(self.communication_history)
        active_handoffs = len([h for h in self.active_handoffs.values() if h["status"] == "active"])
        
        # Calculate message type distribution
        message_type_counts = {}
        for message in self.communication_history:
            msg_type = message.message_type.value
            message_type_counts[msg_type] = message_type_counts.get(msg_type, 0) + 1
        
        # Calculate agent communication patterns
        agent_patterns = {}
        for message in self.communication_history:
            key = f"{message.from_agent.value}_to_{message.to_agent}"
            agent_patterns[key] = agent_patterns.get(key, 0) + 1
        
        return {
            "total_messages": total_messages,
            "active_handoffs": active_handoffs,
            "message_type_distribution": message_type_counts,
            "agent_communication_patterns": agent_patterns,
            "average_handoff_validation_score": self._calculate_average_validation_score(),
            "communication_efficiency": self._calculate_communication_efficiency()
        }
    
    def _calculate_average_validation_score(self) -> float:
        """Calculate average handoff validation score."""
        if not self.active_handoffs:
            return 100.0
        
        scores = [h["validation"].completion_percentage for h in self.active_handoffs.values()]
        return sum(scores) / len(scores)
    
    def _calculate_communication_efficiency(self) -> float:
        """Calculate communication efficiency metric."""
        if not self.communication_history:
            return 100.0
        
        # Simple efficiency metric based on message success rate
        successful_messages = len([m for m in self.communication_history if m.priority != Priority.CRITICAL])
        return (successful_messages / len(self.communication_history)) * 100
    
    def generate_handoff_summary(self) -> str:
        """Generate a summary of all handoffs and communication patterns."""
        summary = []
        summary.append("SPARC Communication Protocol Summary")
        summary.append("=" * 45)
        summary.append("")
        
        metrics = self.get_communication_metrics()
        
        summary.append(f"📊 Communication Metrics:")
        summary.append(f"   Total Messages: {metrics['total_messages']}")
        summary.append(f"   Active Handoffs: {metrics['active_handoffs']}")
        summary.append(f"   Avg Validation Score: {metrics['average_handoff_validation_score']:.1f}%")
        summary.append(f"   Communication Efficiency: {metrics['communication_efficiency']:.1f}%")
        summary.append("")
        
        summary.append("📨 Message Type Distribution:")
        for msg_type, count in metrics['message_type_distribution'].items():
            summary.append(f"   {msg_type}: {count}")
        summary.append("")
        
        summary.append("🤝 Agent Communication Patterns:")
        for pattern, count in metrics['agent_communication_patterns'].items():
            summary.append(f"   {pattern}: {count}")
        summary.append("")
        
        summary.append("✅ Handoff Quality Validation:")
        for handoff_id, handoff_data in self.active_handoffs.items():
            validation = handoff_data["validation"]
            summary.append(f"   {handoff_id}: {validation.completion_percentage:.1f}% validated")
        
        return "\n".join(summary)


# Initialize SPARC communication protocol
sparc_communication = SPARCCommunicationProtocol()